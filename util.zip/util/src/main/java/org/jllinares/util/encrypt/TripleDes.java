package org.jllinares.util.encrypt;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class TripleDes implements CommandLineRunner {

  public static void main(String[] args) {
    log.info("Iniciando Aplicacion");
    SpringApplication.run(TripleDes.class, args);
    log.info("Aplicacion Finalizada");
  }

  @Override
  public void run(String... args) throws Exception {
    log.info("Iniciando proceso");

    if (ArrayUtils.isNotEmpty(args)) {
      log.debug("Se han recibido los siguientes parametros");

      for (String arg : args) {
        log.debug("Argumento: {}", arg);
      }
    }

    log.info("Finalizando proceso");
  }
}
